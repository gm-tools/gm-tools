Taxiway layouts for several international airports derived from Open Street Map using the TaxiGen tool at https://github.com/gm-tools/gm-tools
Note - these data sets are for non-commerical research purposes only. They are not intended for navigation.

Formatting for the "GM" text files can be found here: http://www.asap.cs.nott.ac.uk/external/atr/benchmarks/gmFormattingMAN.shtml
Also included are KML files for each airport, for showing the taxiway layouts in applications such as Google Earth (TM)

The following notice applies to all the data sets.
%%%%%% This data is partly derived from OpenStreetmap, and is copyright OpenStreetMapContributors. %%%%%
%%%%%% It is made available under the Open Database Licence. For more information, see http://www.openstreetmap.org/copyright %%%%%%%
